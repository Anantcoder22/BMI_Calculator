import javax.servlet.*;
import java.io.*;
public class BMICalculator implements Servlet{
	public void init(ServletConfig sc){

	}
	public void service(ServletRequest req,ServletResponse res){
		PrintWriter out=null;
		try{
			out=res.getWriter();
			String n1 = req.getParameter("Weight");
			String n2 = req.getParameter("Height");
			double w = Double.parseDouble(n1);
			double h = Double.valueOf(n2);
			double bmi = w/(h*h)*10000;

			out.print("<html>");
			out.print("<head><title>BMICalculator</title></head>");
			out.print("<body style='height: 50px; font-family: Sans-serif;'><center>");
			out.print("<font size = 6><b>BMI CALCULATOR</b></font>");
			out.print("<hr/><font size=4><br/>");
			out.print("<h3>BMI Report</h3>");
			out.print("<br/>");
			out.print("<p style='margin: 10px; margin-top: 30px'>Your BMI is : "+bmi+"</p>");
			out.print("<br/>");

			out.print("<p style='argin: 10px;'>");
			if(bmi<18.5){
				out.print("You are Under-Weight");
			}
			else if(bmi>24.9){
				out.print("You are Over-Weight");
			}
			else{
				out.print("You are Fit");
			}
			out.print("</p>");
			out.print("<footer style='font-size: 15px; color:blue; text-align: center; bottom: 0; position:fixed; width:100%;'>");
			out.print("*Your BMI should be in range from 18.5 to 24.9");
			out.print("</footer>");
			out.print("</font>");
			out.print("</center>");
			out.print("</body>");
			out.print("</html>");
			out.close();
		}
		catch(Exception ex){
			out.print(ex);
			out.close();
		}

	}
	public void destroy(){

	}
	public ServletConfig getServletConfig(){
		return null;
	}
	public String getServletInfo(){
		return null;
	}
}